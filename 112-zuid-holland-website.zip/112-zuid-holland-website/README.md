# 112 Zuid-Holland — gratis website

## Bestanden
- `index.html` — pagina-structuur
- `style.css` — vormgeving en mobiele layout
- `script.js` — zoeken, categorieën, artikelen, foto's en beheerpaneel

## Belangrijk om te weten
Dit is een statische demo. Er worden geen nep-incidenten getoond. Berichten die je toevoegt via **Beheer berichten** worden in de lokale browser opgeslagen met `localStorage`. Ze verschijnen dus niet automatisch online voor andere bezoekers en synchroniseren niet tussen apparaten. Om echte berichten publiek te publiceren heb je een CMS of een backend nodig (bijvoorbeeld WordPress).

Foto's worden in de browser opgeslagen; houd ze klein (max. 1,5 MB). Maak geregeld een back-up via de knop in het beheerpaneel.

## Gratis online zetten met GitHub Pages
1. Maak een gratis account op https://github.com/
2. Maak een nieuwe repository, bijvoorbeeld `112-zuid-holland`.
3. Upload `index.html`, `style.css`, `script.js` en `README.md` naar de hoofdmap (Code → Add file → Upload files → Commit changes).
4. Open in de repository **Settings → Pages**.
5. Bij **Build and deployment** kies je **Deploy from a branch**.
6. Selecteer branch `main` en map `/ (root)`, druk op **Save**.
7. Wacht even. GitHub toont een websiteadres, meestal `https://JOUW-GEBRUIKERSNAAM.github.io/112-zuid-holland/`.

GitHub Pages host statische bestanden. Het beheerpaneel in deze versie is lokaal voor jou; het is niet geschikt als publiek CMS. Om berichten echt online te publiceren zonder bestanden te uploaden, gebruik je bijvoorbeeld WordPress.com en publiceer je artikelen via het WordPress-dashboard, of laat je later een database/backend toevoegen.

## Aanpassen
- Vervang de naam in `index.html` waar nodig.
- Pas kleuren bovenaan `style.css` aan bij `:root`.
- Voeg geen incidenten toe die niet bevestigd zijn. Gebruik alleen foto's die je rechtmatig mag publiceren.
