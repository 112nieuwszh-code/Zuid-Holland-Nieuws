(() => {
  "use strict";
  const STORAGE_KEY = "112zh_incidents_v1";
  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const grid = $("#incidentGrid");
  const searchInput = $("#searchInput");
  const resultCount = $("#resultCount");
  const emptyState = $("#emptyState");
  const articleDialog = $("#articleDialog");
  const adminDialog = $("#adminDialog");
  let activeFilter = "Alles";
  let incidents = loadIncidents();

  // No fabricated breaking news: the website starts empty until you publish your own reports.
  function loadIncidents() {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch (e) { return []; }
  }
  function saveIncidents() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(incidents));
      return true;
    } catch (e) {
      showToast("Opslaan mislukt. De foto's zijn mogelijk te groot; verklein de foto en probeer opnieuw.");
      return false;
    }
  }
  function escapeHTML(value="") {
    return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  }
  function formatDate(value) {
    if (!value) return "Datum onbekend";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "Datum onbekend";
    return new Intl.DateTimeFormat("nl-NL", {day:"numeric", month:"long", year:"numeric", hour:"2-digit", minute:"2-digit"}).format(date);
  }
  function shortDate(value) {
    if (!value) return "Datum onbekend";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "Datum onbekend";
    return new Intl.DateTimeFormat("nl-NL", {day:"numeric", month:"short", year:"numeric"}).format(date);
  }
  function categoryIcon(category) {
    return ({Brand:"♨",Ongeval:"⚠",Politie:"✦",Overig:"●"})[category] || "●";
  }
  function filteredIncidents() {
    const q = searchInput.value.trim().toLocaleLowerCase("nl");
    return incidents.filter(item => (activeFilter === "Alles" || item.category === activeFilter) &&
      [item.title,item.location,item.summary,item.body,item.category].join(" ").toLocaleLowerCase("nl").includes(q))
      .sort((a,b) => new Date(b.date || b.createdAt || 0) - new Date(a.date || a.createdAt || 0));
  }
  function render() {
    const items = filteredIncidents();
    resultCount.textContent = `${items.length} ${items.length === 1 ? "bericht" : "berichten"}`;
    emptyState.hidden = items.length > 0;
    grid.innerHTML = items.map(item => `
      <article class="incident-card">
        <div class="card-image">
          ${item.photo ? `<img src="${item.photo}" alt="${escapeHTML(item.title)}" loading="lazy">` : `<div class="image-placeholder" aria-label="Geen foto"> ${categoryIcon(item.category)} </div>`}
          <span class="category-tag">${escapeHTML(item.category)}</span>
        </div>
        <div class="card-content">
          <h3>${escapeHTML(item.title)}</h3>
          <div class="card-meta"><span>⌖ ${escapeHTML(item.location)}</span><span>◷ ${escapeHTML(shortDate(item.date || item.createdAt))}</span></div>
          <p>${escapeHTML(item.summary)}</p>
          <button class="read-more" data-open-article="${escapeHTML(item.id)}">Lees artikel <span>→</span></button>
        </div>
      </article>`).join("");
  }
  function openArticle(id) {
    const item = incidents.find(x => x.id === id);
    if (!item) return;
    $("#articleDetail").innerHTML = `
      <article class="article-detail">
        <p class="eyebrow">${escapeHTML(item.category)} · INCIDENTENNIEUWS</p>
        <h1 style="font-family:'Barlow Condensed',sans-serif;font-size:clamp(32px,5vw,48px);line-height:1.05;margin:0 0 12px">${escapeHTML(item.title)}</h1>
        <p class="detail-meta">⌖ ${escapeHTML(item.location)} &nbsp; · &nbsp; ◷ ${escapeHTML(formatDate(item.date || item.createdAt))}</p>
        ${item.photo ? `<img class="detail-image" src="${item.photo}" alt="${escapeHTML(item.title)}">` : ""}
        ${item.credit ? `<p class="detail-meta">${escapeHTML(item.credit)}</p>` : ""}
        <p style="font-size:16px;font-weight:700">${escapeHTML(item.summary)}</p>
        <div class="detail-body">${escapeHTML(item.body)}</div>
        <p class="detail-meta" style="border-top:1px solid #383e48;padding-top:15px;margin-top:25px">Informatie wordt bijgewerkt wanneer bevestigde feiten beschikbaar zijn. Respecteer privacy en volg aanwijzingen van hulpdiensten.</p>
      </article>`;
    articleDialog.showModal();
  }
  function renderManageList() {
    const list = $("#manageList");
    if (!incidents.length) { list.innerHTML = '<p class="field-note">Je hebt nog geen eigen berichten gepubliceerd.</p>'; return; }
    list.innerHTML = incidents.map(item => `<div class="manage-row"><span>${escapeHTML(item.title)} <span class="field-note">(${escapeHTML(item.location)})</span></span><button class="delete-btn" data-delete="${escapeHTML(item.id)}">Verwijderen</button></div>`).join("");
  }
  function showToast(message) {
    const toast = $("#toast");
    toast.textContent = message;
    toast.classList.add("show");
    window.setTimeout(() => toast.classList.remove("show"), 2800);
  }
  function fileToDataURL(file) {
    return new Promise((resolve, reject) => {
      if (!file) return resolve("");
      if (!file.type.startsWith("image/")) return reject(new Error("Kies een afbeeldingsbestand."));
      if (file.size > 1.5 * 1024 * 1024) return reject(new Error("Foto is groter dan 1,5 MB. Verklein de foto eerst."));
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(new Error("Foto kon niet worden gelezen."));
      reader.readAsDataURL(file);
    });
  }

  $$(".filter-btn").forEach(btn => btn.addEventListener("click", () => {
    activeFilter = btn.dataset.filter;
    $$(".filter-btn").forEach(b => b.classList.toggle("active", b === btn));
    render();
  }));
  $$(".nav-link[data-nav-filter]").forEach(link => link.addEventListener("click", () => {
    activeFilter = link.dataset.navFilter;
    $$(".filter-btn").forEach(b => b.classList.toggle("active", b.dataset.filter === activeFilter));
    render();
    $("#mainNav").classList.remove("open");
    $("#menuToggle").setAttribute("aria-expanded", "false");
  }));
  searchInput.addEventListener("input", render);
  grid.addEventListener("click", e => {
    const button = e.target.closest("[data-open-article]");
    if (button) openArticle(button.dataset.openArticle);
  });
  $("#openAdmin").addEventListener("click", () => { renderManageList(); adminDialog.showModal(); });
  $("#menuToggle").addEventListener("click", () => {
    const open = $("#mainNav").classList.toggle("open");
    $("#menuToggle").setAttribute("aria-expanded", String(open));
  });
  $$("[data-close]").forEach(btn => btn.addEventListener("click", () => $("#" + btn.dataset.close).close()));
  [articleDialog, adminDialog].forEach(dialog => dialog.addEventListener("click", e => {
    if (e.target === dialog) dialog.close();
  }));
  $("#incidentForm").addEventListener("submit", async e => {
    e.preventDefault();
    const form = e.currentTarget;
    const fd = new FormData(form);
    const message = $("#formMessage");
    message.textContent = "Bericht wordt opgeslagen…";
    try {
      const photo = await fileToDataURL(fd.get("photo"));
      const item = {
        id: (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random().toString(16).slice(2)),
        title: String(fd.get("title")).trim(),
        location: String(fd.get("location")).trim(),
        category: String(fd.get("category")),
        date: String(fd.get("date")) || new Date().toISOString(),
        summary: String(fd.get("summary")).trim(),
        body: String(fd.get("body")).trim(),
        photo,
        credit: String(fd.get("credit")).trim(),
        createdAt: new Date().toISOString()
      };
      incidents.unshift(item);
      if (!saveIncidents()) { incidents.shift(); message.textContent = "Niet opgeslagen. Verklein de foto en probeer opnieuw."; return; }
      form.reset();
      activeFilter = "Alles";
      $$(".filter-btn").forEach(b => b.classList.toggle("active", b.dataset.filter === "Alles"));
      render();
      renderManageList();
      message.textContent = "Bericht toegevoegd in deze browser.";
      showToast("Bericht toegevoegd. Let op: het staat nog niet automatisch online voor andere bezoekers.");
    } catch (err) {
      message.textContent = err.message || "Er ging iets mis.";
    }
  });
  $("#manageList").addEventListener("click", e => {
    const btn = e.target.closest("[data-delete]");
    if (!btn) return;
    const item = incidents.find(x => x.id === btn.dataset.delete);
    if (!item || !confirm(`Weet je zeker dat je "${item.title}" wilt verwijderen?`)) return;
    incidents = incidents.filter(x => x.id !== btn.dataset.delete);
    saveIncidents();
    render();
    renderManageList();
    showToast("Bericht verwijderd uit deze browser.");
  });
  $("#exportData").addEventListener("click", () => {
    const blob = new Blob([JSON.stringify(incidents, null, 2)], {type:"application/json"});
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "112-zuid-holland-back-up.json"; a.click();
    URL.revokeObjectURL(url);
    showToast("Back-up gedownload.");
  });
  $("#year").textContent = new Date().getFullYear();
  render();
})();